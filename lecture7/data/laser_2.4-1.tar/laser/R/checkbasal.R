`checkbasal` <-
function(x)
{
  if (x[1] == x[2])
    stop("Invalid data format: basal polytomy")
}

